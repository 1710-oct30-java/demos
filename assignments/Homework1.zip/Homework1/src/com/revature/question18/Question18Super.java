package com.revature.question18;

public abstract class Question18Super {
	
	public abstract Boolean uppercase (String s);
	public abstract String lowercaseString (String s);
	public abstract int convertString (String s);

}
