package com.revature.question11two;

public class Question11Two {
	
	public static float first = 6.8f;
	public static float second = 3.7f;
	

}
