package com.revature.question15;

public interface Question15Interface {
	
	public abstract int addition (int a, int b);
	public abstract int subtraction (int a, int b);
	public abstract int multiplication (int a, int b);
	public abstract int division (int a, int b);
	
}
