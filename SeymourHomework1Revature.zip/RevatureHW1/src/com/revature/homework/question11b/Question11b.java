package com.revature.homework.question11b;

public class Question11b {
	public static float f1 = 1.1f;
	public static float f2 = 1.2f;
}
