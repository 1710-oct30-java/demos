package com.revature.homework.question15;

public class Question15Impl implements Question15 {
	
	public double addition(double d1, double d2){
		return d1+d2;
	}
	public double subtraction(double d1, double d2){
		return d1-d2;
	}
	
	public double multiplication(double d1, double d2){
		return d1*d2;
	}
	public double division(double d1, double d2){
		return d1/d2;
	}
	
}
