package com.revature.homework.question15;
// define an interface with additon, substraction, mult, div
// test it
public interface Question15 {
	public double addition(double d1, double d2);
	public double subtraction(double d1, double d2);
	public double multiplication(double d1, double d2);
	public double division(double d1, double d2);
	
}
