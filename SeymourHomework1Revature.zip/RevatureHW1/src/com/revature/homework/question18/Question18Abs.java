package com.revature.homework.question18;

// write a concrete subclass that inherist three abstract methods from a superclass
// implement the 3 methods 
// 1. check for uppercase chars return boolean
// 2. convert all lower case chars to uppercase
// 3. convert the input string to integer and add 10

public abstract class Question18Abs {
	
	public boolean checkUppercase(String str) {
		return true;
	}
	public String convertLowerToUpper(String str) {
		return str;
	}
	public int convertStringToInt(String str) {
		return 0;
	}
}
