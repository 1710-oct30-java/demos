package com.revature.homework.question11a;

public class Question11a {
	public static void main(String[] args) {
		System.out.println(com.revature.homework.question11b.Question11b.f1);
		System.out.println(com.revature.homework.question11b.Question11b.f2);
	}
}
