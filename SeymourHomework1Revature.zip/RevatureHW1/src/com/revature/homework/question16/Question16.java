package com.revature.homework.question16;

import java.util.Scanner;

// Write a program to display the number of characters for a string input
// The string should be entered from the command line using String[] args

public class Question16 {
	
	public static void main(String[] args) {
		System.out.println("The number of args is: "+ args.length);
	}
//		Scanner input = new Scanner(System.in);
//		
//		System.out.println("Enter a string");
//		String s = input.nextLine();
//		System.out.println("That string has "+ s.length() + " characters");
//	}
//	
//	public static int determineNumOfChars(String str) {
//		int i = str.length();
//		return i;
//	}
}
