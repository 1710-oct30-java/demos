package com.revature.Q10;

public class Minimum {
	public static void main(String[] args) {
		int x = 6;
		int y = 3;
		int z = 0;
		
		z = (x < y)? x:y;
		
		
		System.out.println(z);
	}
}
