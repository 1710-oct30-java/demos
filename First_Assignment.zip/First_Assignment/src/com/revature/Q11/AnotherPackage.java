package com.revature.Q11;

import com.revature.Q12.QuestionEleven;

public class AnotherPackage {
	public static void main (String[] args) {
		System.out.println(QuestionEleven.getX());
		System.out.println(QuestionEleven.getY());
	}
}
