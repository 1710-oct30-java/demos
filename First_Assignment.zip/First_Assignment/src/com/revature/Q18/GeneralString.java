package com.revature.Q18;

public class GeneralString {
	
	
	public GeneralString() {
		
	}
	
	public boolean checkCase(String s) {
		return false;
	}
	
	public String setCase(String s) {
		return s;
	}
	
	public int convert(String s) {
		return 0;
	}
}
