package com.revature.Q12;

public class QuestionEleven {
	public static float x = 11;
	public static float y = 12;
	
	public static float getX() {
		return x;
	}
	public void setX(float x) {
		this.x = x;
	}
	public static float getY() {
		return y;
	}
	public void setY(float y) {
		this.y = y;
	}
}
