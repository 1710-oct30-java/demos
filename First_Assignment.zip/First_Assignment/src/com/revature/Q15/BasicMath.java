package com.revature.Q15;

public interface BasicMath {
	
	public int addition(int x, int y);
	
	public int subtraction(int x, int y);
	
	public int multiplication(int x, int y);
	
	public int division(int x, int y);
}
