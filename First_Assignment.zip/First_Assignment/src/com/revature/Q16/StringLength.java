package com.revature.Q16;

public class StringLength {
	public static void main (String[] args) {
		
		//String s = "leeeeeeeeength";
		//args[0] = s;
		
		for (int i = 0; i < args.length; i ++) {
			System.out.println(args[i].length());
		}
	}
}
